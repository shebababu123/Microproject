package com.example.patienttracker;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class doctor_login extends AppCompatActivity {
    EditText demail,dpassword;
    Button blogin;
    TextView signup, back;
    SQLiteDatabase patient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_login);

        this.getSupportActionBar().hide();
        demail=(EditText)findViewById(R.id.lemail);
        dpassword=(EditText)findViewById(R.id.lpassword);
        blogin=(Button)findViewById(R.id.Btn_login);
        signup=(TextView)findViewById(R.id.Gsignup1);
        back=(TextView)findViewById(R.id.back);
        patient = openOrCreateDatabase("PatientTrackerDb", Context.MODE_PRIVATE, null);
        if (patient != null)
        {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        patient.execSQL("CREATE TABLE IF NOT EXISTS dregister(dname VARCHAR,sp VARCHAR,dphone VARCHAR,demail VARCHAR,dpassword VARCHAR);");
        blogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor c = patient.rawQuery("SELECT * FROM dregister WHERE demail='" + demail.getText() + "' and dpassword='" + dpassword.getText() + "'", null);


                if (c.moveToFirst()) {
                    showMessage("Success", "Login Success !");
                    clearText();
                    Intent in = new Intent(doctor_login.this, DoctorHome.class);
                    startActivity(in);
                    return;
                } else {
                    showMessage("Error", "Invalid Login!");
                    clearText();
                    return;

                }
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent in = new Intent(doctor_login.this, doctor_signup.class);
                startActivity(in);
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(doctor_login.this,MainActivity.class);
                startActivity(i);
            }
        });



    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {

        demail.setText(" ");
        dpassword.setText(" ");
        demail.requestFocus();
    }

}
