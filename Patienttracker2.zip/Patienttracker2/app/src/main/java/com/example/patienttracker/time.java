package com.example.patienttracker;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class time extends AppCompatActivity {
    EditText m,e;
    Button ok;
    SQLiteDatabase patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        m=(EditText)findViewById(R.id.morning);
        e=(EditText)findViewById(R.id.evening);
        ok=(Button)findViewById(R.id.ok);

        patient = openOrCreateDatabase("PatientTrackerDb", Context.MODE_PRIVATE, null);
        if (patient != null) {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        patient.execSQL("CREATE TABLE IF NOT EXISTS dtime(morning VARCHAR,evening VARCHAR);");

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (m.getText().toString().trim().length() == 0 ||
                        e.getText().toString().trim().length()==0){
                    showMessage("Error", "Please Fill all the fields");
                    return;
                }
                patient.execSQL("INSERT INTO dtime VALUES('" + m.getText() + "',' " + e.getText() +"');");
                showMessage("Success", "Duty Time Entered!");
                clearText();

                Intent in = new Intent(time.this, DoctorHome.class);
                startActivity(in);
            }
        });

    }

    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        m.setText("");
        e.setText(" ");
        m.requestFocus();
    }
}
