package com.example.patienttracker;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class doctor_signup extends AppCompatActivity {
    EditText dname,sp,dphone,demail,dpassword;
    Button btn_signup;
    TextView dlogin;
    SQLiteDatabase patient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_signup);
        this.getSupportActionBar().hide();

        dname=(EditText)findViewById(R.id.dname);
        sp=(EditText)findViewById(R.id.sp);
        dphone=(EditText)findViewById(R.id.dphone);
        demail=(EditText)findViewById(R.id.demail);
        dpassword=(EditText)findViewById(R.id.dpassword);
        btn_signup=(Button)findViewById(R.id.btn_signup);
        dlogin=(TextView)findViewById(R.id.dlogin);

        patient = openOrCreateDatabase("PatientTrackerDb", Context.MODE_PRIVATE, null);
        if (patient != null) {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        patient.execSQL("CREATE TABLE IF NOT EXISTS dregister(dname VARCHAR,sp VARCHAR,dphone VARCHAR,demail VARCHAR,dpassword VARCHAR);");

        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (dname.getText().toString().trim().length() == 0 ||
                        sp.getText().toString().trim().length() == 0 ||
                        dphone.getText().toString().trim().length() == 0 ||
                        demail.getText().toString().trim().length() == 0 ||
                        dpassword.getText().toString().trim().length() == 0)
                {

                    showMessage("Error", "Please Fill all the fields");
                    return;
                }

                patient.execSQL("INSERT INTO dregister VALUES('"+dname.getText()+"','"+sp.getText()+"','"+dphone.getText()+"','"+demail.getText()+"','"+dpassword.getText()+"');");

                showMessage("Success","Signup Successfull !");
                clearText();
                Intent in=new Intent(doctor_signup.this,doctor_login.class);
                startActivity(in);
            }

        });
        dlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(doctor_signup.this,doctor_login.class);
                startActivity(in);
            }
        });
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        dname.setText("");
        sp.setText("");
        dphone.setText("");
        demail.setText("");
        dpassword.setText("");
        dname.requestFocus();
    }
}
