package com.example.patienttracker;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewParent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    EditText lemail,lpassword;
    Button blogin;
    TextView signup,signup3;
    SQLiteDatabase patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        this.getSupportActionBar().hide();
        lemail=(EditText)findViewById(R.id.lemail);
        lpassword=(EditText)findViewById(R.id.lpassword);
        blogin=(Button)findViewById(R.id.Btn_login);
        signup=(TextView)findViewById(R.id.Gsignup);
        signup3=(TextView)findViewById(R.id.Gsignup2);
        patient = openOrCreateDatabase("PatientTrackerDb", Context.MODE_PRIVATE, null);
        if (patient != null)
        {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        patient.execSQL("CREATE TABLE IF NOT EXISTS reg(pname VARCHAR,pdob VARCHAR,pgender VARCHAR,paddress VARCHAR,pphone VARCHAR,phistory VARCHAR,pemail VARCHAR,ppassword VARCHAR);");
        blogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Cursor c = patient.rawQuery("SELECT * FROM reg WHERE pemail='"+lemail.getText()+"' and ppassword='"+lpassword.getText()+"'", null);

                if (c.moveToFirst())
                {

                    showMessage("Success", "Login Success !");
                    clearText();
                    Intent in=new Intent(MainActivity.this,PatientHome.class);
                    startActivity(in);
                    return;


                }
                else
                {

                    showMessage("Error", "Invalid Login!");
                    clearText();
                    return;

                }

            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent in=new Intent(MainActivity.this,signup1.class);
                startActivity(in);
            }
        });

        signup3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(MainActivity.this,doctor_login.class);
                startActivity(in);
            }
        });

    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {

        lemail.setText("");
        lpassword.setText("");
        lemail.requestFocus();
    }

}
