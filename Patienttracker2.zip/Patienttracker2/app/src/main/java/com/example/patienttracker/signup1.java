package com.example.patienttracker;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class signup1 extends AppCompatActivity {

    EditText pname,pdob,pgender,paddress,pphone,phistory,pemail,ppassword;
    Button bsignup;
    TextView login;
    SQLiteDatabase patient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup1);
        this.getSupportActionBar().hide();

        pname=(EditText)findViewById(R.id.name);
        pdob=(EditText)findViewById(R.id.dob);
        pgender=(EditText)findViewById(R.id.gender);
        paddress=(EditText)findViewById(R.id.address);
        pphone=(EditText)findViewById(R.id.phone);
        phistory=(EditText)findViewById(R.id.history);
        pemail=(EditText)findViewById(R.id.email);
        ppassword=(EditText)findViewById(R.id.password);
        bsignup=(Button)findViewById(R.id.bSignup);
        login=(TextView)findViewById(R.id.tvlogin);

        patient = openOrCreateDatabase("PatientTrackerDb", Context.MODE_PRIVATE, null);
        if (patient != null) {
            Toast.makeText(this, "Created/Opened", Toast.LENGTH_SHORT).show();
        }
        patient.execSQL("CREATE TABLE IF NOT EXISTS reg(pname VARCHAR,pdob VARCHAR,pgender VARCHAR, paddress VARCHAR, pphone VARCHAR, phistory VARCHAR, pemail VARCHAR,ppassword VARCHAR);");

        bsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (pname.getText().toString().trim().length() == 0 ||
                        pdob.getText().toString().trim().length() == 0 ||
                        pgender.getText().toString().trim().length() == 0 ||
                        paddress.getText().toString().trim().length() == 0 ||
                        pphone.getText().toString().trim().length() == 0 ||
                        phistory.getText().toString().trim().length() == 0 ||
                        pemail.getText().toString().trim().length() == 0 ||
                        ppassword.getText().toString().trim().length() == 0)
                {

                    showMessage("Error", "Please Fill all the fields");
                    return;
                }

                patient.execSQL("INSERT INTO reg VALUES('"+pname.getText()+"','"+pdob.getText()+"','"+pgender.getText()+"','"+paddress.getText()+"'," +
                        "'"+pphone.getText()+"','"+phistory.getText()+"','"+pemail.getText()+"','"+ppassword.getText()+"');");

                showMessage("Success","Signup Successfull !");
                clearText();
                Intent in=new Intent(signup1.this,MainActivity.class);
                startActivity(in);
            }

        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(signup1.this,MainActivity.class);
                startActivity(in);
            }
        });
    }
    public void showMessage(String title,String message)
    {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText() {
        pname.setText("");
        pdob.setText("");
        pgender.setText("");
        paddress.setText("");
        pphone.setText("");
        phistory.setText("");
        pemail.setText("");
        ppassword.setText("");
        pname.requestFocus();
    }
}

