package com.example.patienttracker;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class PatientConsult extends AppCompatActivity {
    EditText s,date;
    Button b1;

    SQLiteDatabase patient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_consult);
        s = (EditText) findViewById(R.id.s);
        date = (EditText) findViewById(R.id.date);
        b1 = (Button) findViewById(R.id.ok);

        patient = openOrCreateDatabase("PatientTrackerDb", Context.MODE_PRIVATE, null);

        if (patient != null) {
            Toast.makeText(this, "Created", Toast.LENGTH_SHORT).show();
        }
        patient.execSQL("CREATE TABLE IF NOT EXISTS consult(doname VARCHAR , date VARCHAR);");


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (s.getText().toString().trim().length() == 0 ||
                        date.getText().toString().trim().length() == 0) {

                    showMessage("Error", "Please Fill all the fields");

                }
                patient.execSQL("INSERT INTO consult VALUES('" + s.getText() + "',''" + date.getText() + "');");

                showMessage("Success", "Information is added !");
                clearText();
                Intent in = new Intent(PatientConsult.this, PatientHome.class);
                startActivity(in);

            }
        });

    }
        public void showMessage(String title,String message)
        {
            AlertDialog.Builder builder=new AlertDialog.Builder(this);
            builder.setCancelable(true);
            builder.setTitle(title);
            builder.setMessage(message);
            builder.show();
        }
        public void clearText() {
            s.setText("");
            date.setText("");
            s.requestFocus();
    }

}
